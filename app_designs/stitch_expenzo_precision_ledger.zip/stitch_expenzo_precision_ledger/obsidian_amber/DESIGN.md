---
name: Obsidian & Amber
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393f'
  surface-container-lowest: '#0c0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#282a2f'
  surface-container-highest: '#33353a'
  on-surface: '#e2e2e9'
  on-surface-variant: '#d6c4b0'
  inverse-surface: '#e2e2e9'
  inverse-on-surface: '#2e3036'
  outline: '#9e8e7c'
  outline-variant: '#514536'
  surface-tint: '#ffb956'
  primary: '#ffc16c'
  on-primary: '#462b00'
  primary-container: '#e8a33d'
  on-primary-container: '#5f3c00'
  inverse-primary: '#835400'
  secondary: '#c4c5da'
  on-secondary: '#2d2f40'
  secondary-container: '#46485a'
  on-secondary-container: '#b6b7cc'
  tertiary: '#abd6be'
  on-tertiary: '#0e3727'
  tertiary-container: '#90baa4'
  on-tertiary-container: '#234b39'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb5'
  primary-fixed-dim: '#ffb956'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#643f00'
  secondary-fixed: '#e1e1f7'
  secondary-fixed-dim: '#c4c5da'
  on-secondary-fixed: '#181a2a'
  on-secondary-fixed-variant: '#444657'
  tertiary-fixed: '#c1ecd4'
  tertiary-fixed-dim: '#a5d0b9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#274e3d'
  background: '#111318'
  on-background: '#e2e2e9'
  surface-variant: '#33353a'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  currency-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  container-max: 1200px
  gutter: 20px
---

## Brand & Style
The design system embodies a premium, high-fidelity fintech experience through a fusion of **Minimalist Discipline** and **Sophisticated Glassmorphism**. The aesthetic is designed to evoke a sense of "digital craftsmanship"—where the precision of finance meets the warmth of luxury materials.

The UI relies on depth and transparency rather than heavy color fills. It uses a rigorous dark-mode-first approach for the obsidian environment, punctuated by vibrant amber highlights that act as beacons for the user's focus. The emotional response is one of security, exclusivity, and clarity.

## Colors
This design system utilizes a dual-mode strategy centered on high-contrast luxury.

- **Obsidian (#0B0D12)**: The primary canvas for dark mode, providing a deep, ink-like foundation that allows glass layers to pop.
- **Amber/Copper (#E8A33D)**: Reserved exclusively for primary actions and critical financial data. In light mode, this shifts to a slightly deeper tone (#C67C1F) to maintain legibility against the Bone background.
- **Bone (#FAF7F2)**: The airy, sophisticated alternative for light mode interfaces.
- **Semantic Logic**: Financial indicators follow a "Muted Forest" for growth and "Deep Crimson" for outflows, ensuring accessibility without breaking the refined palette.

## Typography
The typography strategy creates a clear distinction between **Data (Display)** and **Context (Body)**.

- **Plus Jakarta Sans**: Used for headlines, large currency values, and navigation titles. Its soft but modern geometry adds personality to the financial data.
- **Inter**: The workhorse for all functional text, descriptions, and labels. It ensures maximum readability at small sizes within dense financial lists.
- **Currency Formatting**: Always prefix values with the Indian Rupee symbol (₹). Use `currency-display` for the primary balance on any screen, set in the Amber accent color.

## Layout & Spacing
The layout adheres to a **Fixed Grid** philosophy for desktop (12 columns) and a **Fluid Margin** approach for mobile (4 columns). 

Spacing is governed by a 4px baseline, but the "Minimalist Discipline" aspect of the system requires generous white space (typically `md` or `lg` units) to prevent the glass elements from feeling cluttered. Content blocks should be separated by clear vertical rhythms, with card-based layouts using `sm` (16px) internal padding.

## Elevation & Depth
Depth is created through **Glassmorphism** rather than traditional drop shadows.

1.  **Base Layer**: The Obsidian background (#0B0D12).
2.  **Glass Layer**: Cards and containers use `rgba(30, 32, 48, 0.6)` with a `backdrop-blur-xl` (24px).
3.  **Definition**: Every glass surface must have a 1px solid border at `rgba(232, 163, 61, 0.15)` to provide structural "edge-lighting," mimicking the way light hits the edge of a cut gemstone.
4.  **Interactive States**: When hovered or pressed, the backdrop-blur increases slightly, and the border opacity increases to 0.3.

## Shapes
The shape language is modern and approachable without being overly "bubbly."

- **Cards**: A 16px radius (`rounded-lg` equivalent) is standard for all main container elements to create a soft, premium feel.
- **Controls**: Buttons and input fields use a slightly tighter 12px radius, signaling their interactive nature and distinguishing them from structural containers.
- **Iconography**: Icons should be linear, 2px stroke weight, with slightly rounded terminals to match the font geometry.

## Components
- **Primary Buttons**: Solid Amber fill (#E8A33D) with black text. High contrast, used only for the final conversion or "Add" action.
- **Glass Buttons**: Transparent background with `backdrop-blur`, 1px border, and Amber text. Used for secondary actions.
- **Inputs**: Glass background with 12px radius. The label should be `label-caps` in a muted grey, floating above the field. Focus state increases border opacity.
- **Currency Cards**: The main display of a balance. Must use a glass surface. The INR (₹) symbol and the amount should be the only elements using the solid Amber color if they represent the "Single Important Number."
- **Transaction Lists**: Flat layout with 1px separators (rgba(255,255,255,0.05)). Icons for transactions are placed in small glass circles.
- **Data Visualization**: Charts should use thin, glowing lines in Amber or Forest Green, with subtle area gradients beneath the lines using 5% opacity.